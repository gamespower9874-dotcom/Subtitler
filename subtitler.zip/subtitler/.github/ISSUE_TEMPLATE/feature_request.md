---
name: Feature request
about: Suggest an improvement
title: "[Feature] "
labels: enhancement
---

**What would you like?**

**Why is it useful?**

**Alternatives considered**
